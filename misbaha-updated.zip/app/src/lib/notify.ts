import { Capacitor } from '@capacitor/core'
import { LocalNotifications } from '@capacitor/local-notifications'
import { arNum } from '@/lib/model'

// إشعار دائم في شريط الإشعارات يعرض كم بقي من الأثر المستهدف
const ID = 7001
const CHANNEL = 'misbaha-live'
const MIN_GAP_MS = 1500

export type NoticeData = {
  goal: number // الأثر المستهدف (دقيقة)
  eff: number // الأثر الحالي المقدَّر (دقيقة)
  dhikr: string
  count: number
  target: number
  running: boolean
}

let ready: Promise<boolean> | null = null
let last = 0
let timer: number | undefined
let pending: NoticeData | null = null

function ensure(): Promise<boolean> {
  if (!Capacitor.isNativePlatform()) return Promise.resolve(false)
  if (!ready) {
    ready = (async () => {
      try {
        let p = await LocalNotifications.checkPermissions()
        if (p.display !== 'granted') p = await LocalNotifications.requestPermissions()
        if (p.display !== 'granted') { ready = null; return false }
        await LocalNotifications.createChannel({
          id: CHANNEL,
          name: 'تقدّم الأثر',
          description: 'شريط دائم يعرض كم بقي من الأثر المستهدف',
          importance: 2, // منخفضة: بلا صوت ولا اهتزاز عند كل تحديث
          visibility: 1,
          vibration: false,
          lights: false,
        })
        return true
      } catch {
        ready = null
        return false
      }
    })()
  }
  return ready
}

function bar(ratio: number, n = 12): string {
  const f = Math.round(Math.min(1, Math.max(0, ratio)) * n)
  return '▰'.repeat(f) + '▱'.repeat(n - f)
}

async function post(d: NoticeData) {
  if (!(await ensure())) return
  const ratio = d.goal > 0 ? d.eff / d.goal : 0
  const pct = Math.min(100, Math.floor(ratio * 100))
  const remain = Math.max(0, d.goal - d.eff)
  const finished = d.eff >= d.goal
  const title = finished
    ? 'اكتمل الأثر المستهدف 🎉'
    : remain < 1
      ? 'باقٍ من الأثر: أقل من دقيقة'
      : `باقٍ من الأثر: ${arNum(Math.ceil(remain))} دقيقة`
  const body = `${bar(ratio)}  ${arNum(pct)}٪`
  const big = [
    body,
    `الأثر: ${arNum(Math.floor(d.eff))} من ${arNum(d.goal)} دقيقة`,
    `${d.dhikr}: ${arNum(d.count)} / ${arNum(d.target)}`,
    d.running ? 'المكوث جارٍ' : 'متوقف',
  ].join('\n')
  await LocalNotifications.schedule({
    notifications: [{
      id: ID,
      channelId: CHANNEL,
      title,
      body,
      largeBody: big,
      summaryText: 'مِسبحة',
      ongoing: true,
      autoCancel: false,
    }],
  })
}

function flush() {
  timer = undefined
  if (!pending) return
  const d = pending
  pending = null
  last = Date.now()
  post(d).catch(() => { /* ignore */ })
}

/** تحديث الإشعار (مع تهدئة حتى لا يُرسَل أكثر من مرة كل ~1.5 ثانية) */
export function updateNotice(d: NoticeData) {
  if (!Capacitor.isNativePlatform()) return
  pending = d
  const wait = MIN_GAP_MS - (Date.now() - last)
  if (wait <= 0) flush()
  else if (timer === undefined) timer = window.setTimeout(flush, wait)
}

export function clearNotice() {
  pending = null
  if (timer !== undefined) { window.clearTimeout(timer); timer = undefined }
  if (!Capacitor.isNativePlatform()) return
  LocalNotifications.cancel({ notifications: [{ id: ID }] }).catch(() => { /* ignore */ })
}
