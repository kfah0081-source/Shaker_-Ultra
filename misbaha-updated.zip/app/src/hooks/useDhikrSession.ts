import { useCallback, useEffect, useRef, useState } from 'react'
import { toast } from 'sonner'
import { active, freqAt, persistenceAt } from '@/lib/model'
import { BASE, DONE, KINDS, load, save, type Profile, type Session } from '@/lib/store'
import { clearNotice, updateNotice } from '@/lib/notify'

export type TracePoint = { t: number; f: number }
export type Dhikr = Profile
const IDLE_MS = 30000

// الجلسة الجارية كما تُحفظ على الجهاز حتى لا يضيع التقدم عند إغلاق التطبيق
type Live = { id: string; count: number; rounds: number; total: number; elapsed: number; done: boolean; trace: TracePoint[] }
const thin = (tr: TracePoint[], max = 600) => { const k = Math.ceil(tr.length / max); return k > 1 ? tr.filter((_, i) => i % k === 0) : tr }

export function useDhikrSession() {
  const [live] = useState<Live | null>(() => {
    const v = load<Live | null>('live', null)
    return v && v.id === load<string>('last', BASE[0].id) ? v : null
  })
  const [running, setRunning] = useState(false)
  const [elapsedSec, setElapsedSec] = useState(live?.elapsed ?? 0)
  const [count, setCount] = useState(live?.count ?? 0)
  const [rounds, setRounds] = useState(live?.rounds ?? 0)
  const [total, setTotal] = useState(live?.total ?? 0)
  const [trace, setTrace] = useState<TracePoint[]>(live?.trace ?? [])
  const [noticeOn, setNoticeOnS] = useState<boolean>(() => load('notice', true))
  const [pulse, setPulse] = useState(0)
  const [rhythm, setRhythm] = useState({ avg: 0, reg: 0 })
  const gaps = useRef<number[]>([])
  const lastReal = useRef(0)
  const [customs, setCustoms] = useState<Profile[]>(() => load('customs', []))
  const [sessions, setSessions] = useState<Session[]>(() => load('sessions', []))
  const [goal, setGoalS] = useState<number>(() => load('goal', 30))
  const [targets, setTargets] = useState<Record<string, number>>(() => load('targets', {}))
  const [dhikrId, setDhikrId] = useState<string>(() => load('last', BASE[0].id))

  const adhkar = [...BASE, ...customs].map((d) => ({ ...d, target: targets[d.id] ?? d.target }))
  const dhikr = adhkar.find((d) => d.id === dhikrId) ?? adhkar[0]
  active.fTheta = dhikr.fTheta
  active.tMid = dhikr.tMid

  const accRef = useRef(live?.elapsed ?? 0)
  const stampRef = useRef<number | null>(null)
  const lastTap = useRef(0)
  const done = useRef(live?.done ?? false)
  const flags = useRef([0.5, 0.9, 1].map((r) => (live ? persistenceAt(live.elapsed / 60) >= goal * r : false)))
  const idRef = useRef(dhikrId)
  const roundsRef = useRef(rounds)
  const traceRef = useRef(trace)
  const noticeRef = useRef(noticeOn)
  const tickRef = useRef(0)
  const dhikrRef = useRef(dhikr)
  const totalRef = useRef(total)
  const goalRef = useRef(goal)
  const countRef = useRef(count)
  countRef.current = count
  idRef.current = dhikrId
  roundsRef.current = rounds
  traceRef.current = trace
  noticeRef.current = noticeOn
  dhikrRef.current = dhikr
  totalRef.current = total
  goalRef.current = goal

  const getElapsed = useCallback(() => {
    if (stampRef.current == null) return accRef.current
    return accRef.current + (performance.now() - stampRef.current) / 1000
  }, [])

  // حفظ الجلسة الجارية (العدّاد والجولات والوقت والمسار)
  const persist = useCallback(() => {
    save('live', {
      id: idRef.current,
      count: countRef.current,
      rounds: roundsRef.current,
      total: totalRef.current,
      elapsed: getElapsed(),
      done: done.current,
      trace: thin(traceRef.current),
    } satisfies Live)
  }, [getElapsed])

  // الإشعار الدائم: كم بقي من الأثر المستهدف
  const pushNotice = useCallback(() => {
    if (!noticeRef.current) return
    const d = dhikrRef.current
    updateNotice({
      goal: goalRef.current,
      eff: persistenceAt(getElapsed() / 60),
      dhikr: d.text,
      count: countRef.current,
      target: d.target,
      running: stampRef.current != null,
    })
  }, [getElapsed])

  const fresh = useCallback(() => {
    totalRef.current = 0
    traceRef.current = []
    accRef.current = 0
    stampRef.current = null
    done.current = false
    flags.current = [false, false, false]
    setRunning(false)
    setElapsedSec(0)
    setTotal(0)
    setTrace([])
    gaps.current = []
    lastReal.current = 0
    setRhythm({ avg: 0, reg: 0 })
  }, [])

  // حفظ الجلسة في السجل
  const commit = useCallback(() => {
    const e = getElapsed()
    if (done.current || e < 5) return
    done.current = true
    const m = e / 60
    let s = 0, n = 0
    for (let t = 0; t <= m; t += 0.25) { s += freqAt(t); n++ }
    const rec: Session = { ts: Date.now(), id: dhikrRef.current.id, sec: e, count: totalRef.current, eff: persistenceAt(m), avgF: s / n }
    setSessions((p) => { const x = [...p, rec].slice(-500); save('sessions', x); return x })
  }, [getElapsed])

  const start = useCallback(() => {
    if (stampRef.current != null) return
    if (done.current) fresh()
    lastTap.current = performance.now()
    stampRef.current = performance.now()
    setRunning(true)
  }, [fresh])

  const pause = useCallback(() => {
    if (stampRef.current == null) return
    accRef.current = getElapsed()
    stampRef.current = null
    setRunning(false)
  }, [getElapsed])

  const reset = useCallback(() => {
    pause()
    commit()
    fresh()
    countRef.current = 0
    roundsRef.current = 0
    setCount(0)
    setRounds(0)
    persist()
  }, [pause, commit, fresh, persist])

  // تصفير كامل يدوي: العدّاد والجولات والوقت وسجل الجلسات والإحصاء
  const resetAll = useCallback(() => {
    pause()
    fresh()
    countRef.current = 0
    roundsRef.current = 0
    setCount(0)
    setRounds(0)
    setSessions([])
    save('sessions', [])
    persist()
    toast('تم تصفير كل التقدم والسجل')
  }, [pause, fresh, persist])

  const setNotice = useCallback((on: boolean) => { setNoticeOnS(on); save('notice', on) }, [])

  const tap = useCallback(() => {
    if (done.current) fresh()
    const now = performance.now()
    if (lastReal.current && now - lastReal.current < IDLE_MS) {
      gaps.current = [...gaps.current, (now - lastReal.current) / 1000].slice(-20)
      const g = gaps.current
      const avg = g.reduce((a, b) => a + b, 0) / g.length
      const sd = Math.sqrt(g.reduce((a, b) => a + (b - avg) ** 2, 0) / g.length)
      setRhythm({ avg, reg: Math.round(100 * Math.max(0, 1 - sd / avg)) })
    }
    lastReal.current = now
    lastTap.current = now
    if (stampRef.current == null) {
      stampRef.current = performance.now()
      setRunning(true)
    }
    if (countRef.current + 1 >= dhikrRef.current.target) {
      toast(DONE[dhikrRef.current.id] ?? 'بلغتَ غايتك من هذا الذكر، تقبّل الله منك')
      navigator.vibrate?.(60)
    }
    setPulse((p) => p + 1)
    setTotal((t) => t + 1)
    setCount((c) => {
      if (c + 1 >= dhikrRef.current.target) { setRounds((r) => r + 1); return 0 }
      return c + 1
    })
  }, [fresh])

  const undo = () => {
    if (totalRef.current <= 0) return
    setTotal((t) => Math.max(0, t - 1))
    setCount((c) => {
      if (c > 0) return c - 1
      setRounds((r) => Math.max(0, r - 1))
      return Math.max(0, dhikrRef.current.target - 1)
    })
  }
  const addManual = (id: string, n: number, min: number, ts: number, mode: 'whisper' | 'loud') => {
    const d = adhkar.find((x) => x.id === id) ?? adhkar[0]
    const keep = [active.fTheta, active.tMid]
    active.fTheta = d.fTheta; active.tMid = d.tMid
    let s = 0, k = 0
    for (let t = 0; t <= min; t += 0.25) { s += freqAt(t); k++ }
    const rec: Session = { ts, id: d.id, sec: min * 60, count: n, eff: persistenceAt(min), avgF: s / k, mode, manual: true }
    active.fTheta = keep[0]; active.tMid = keep[1]
    setSessions((p) => { const x = [...p, rec].slice(-500); save('sessions', x); return x })
  }

  const selectDhikr = useCallback((id: string) => {
    pause(); commit(); fresh()
    setDhikrId(id); save('last', id)
    idRef.current = id
    countRef.current = 0; roundsRef.current = 0
    setCount(0); setRounds(0)
    persist()
  }, [pause, commit, fresh, persist])

  const setTarget = (id: string, n: number) =>
    setTargets((p) => { const x = { ...p, [id]: n }; save('targets', x); return x })
  const setGoal = (n: number) => { setGoalS(n); save('goal', n) }
  const addCustom = (text: string, target: number, kind: keyof typeof KINDS, meaning = 'ذكر مخصّص', mode: 'whisper' | 'loud' = 'loud') => {
    const k = KINDS[kind]
    const p: Profile = { id: 'c' + Date.now(), text, target, meaning, effect: k.effect, fTheta: k.fTheta, tMid: k.tMid, custom: true, mode }
    setCustoms((c) => { const x = [...c, p]; save('customs', x); return x })
    setDhikrId(p.id); save('last', p.id)
  }

  useEffect(() => {
    const iv = window.setInterval(() => {
      const e = getElapsed()
      setElapsedSec(e)
      if (stampRef.current == null) return
      // إيقاف تلقائي بعد 30 ثانية دون ذكر، وخصم مدة الخمول
      if (performance.now() - lastTap.current > IDLE_MS) {
        // الوقت محسوب حتى آخر ذكر فعلي (حتى لو بقي التطبيق في الخلفية مدة طويلة)
        accRef.current = Math.max(0, accRef.current + (lastTap.current - (stampRef.current ?? lastTap.current)) / 1000)
        stampRef.current = null
        setRunning(false)
        setElapsedSec(accRef.current)
        commit()
        toast('توقف العداد تلقائياً بعد 30 ثانية دون ذكر')
        return
      }
      tickRef.current++
      if (tickRef.current % 8 === 0) persist()
      if (tickRef.current % 16 === 0) pushNotice()
      const tMin = e / 60
      setTrace((tr) => {
        const last = tr[tr.length - 1]
        if (last && Math.abs(last.t - tMin) < 1 / 240) return tr
        const next = [...tr, { t: tMin, f: freqAt(tMin) }]
        return next.length > 7200 ? next.slice(-7200) : next
      })
      const eff = persistenceAt(tMin)
      const marks: [number, string][] = [[0.5, 'بلغت نصف الأثر المستهدف'], [0.9, 'اقتربت من اكتمال الأثر المستهدف'], [1, 'اكتمل الأثر المستهدف 🎉']]
      marks.forEach(([r, msg], i) => {
        if (!flags.current[i] && eff >= goalRef.current * r) {
          flags.current[i] = true
          toast(msg)
          navigator.vibrate?.(200)
        }
      })
    }, 250)
    return () => window.clearInterval(iv)
  }, [getElapsed, commit, persist, pushNotice])

  // حفظ فوري عند تغيّر التقدم أو عند إيقاف/استئناف المكوث
  useEffect(() => { persist() }, [count, rounds, total, running, dhikrId, persist])

  // حفظ عند مغادرة التطبيق أو إخفائه
  useEffect(() => {
    const onHide = () => { if (document.visibilityState !== 'visible') persist() }
    document.addEventListener('visibilitychange', onHide)
    window.addEventListener('pagehide', persist)
    return () => { document.removeEventListener('visibilitychange', onHide); window.removeEventListener('pagehide', persist) }
  }, [persist])

  // الإشعار الدائم
  useEffect(() => { if (noticeOn) pushNotice(); else clearNotice() }, [noticeOn, pushNotice])
  useEffect(() => { pushNotice() }, [count, rounds, running, goal, dhikr.id, dhikr.target, targets, pushNotice])

  return { running, elapsedSec, getElapsed, count, rounds, total, dhikr, adhkar, trace, pulse, sessions, goal, start, pause, reset, resetAll, noticeOn, setNotice, tap, undo, addManual, rhythm, selectDhikr, setTarget, setGoal, addCustom }
}
