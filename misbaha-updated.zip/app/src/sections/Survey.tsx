import { useState } from 'react'
import { load, save } from '@/lib/store'

const STATES = ['أنا متعب', 'أنا مسترخٍ', 'أنا متوتر', 'أنا ممتن', 'أنا نشيط', 'أشعر بتشتت', 'أحتاج إلى السكينة', 'أحتاج إلى التركيز']
const QIYAM = ['لقد قمت الليل', 'سأقوم الليل', 'لم أصلِّ قيام الليل', 'لا أريد تحديد ذلك']
type S = { st: string[]; caf: boolean; cafH: number; fast: boolean; sadaqa: boolean; qBefore: number; qAfter: number; qiyam: string; sujood: number; dua: number }
const D: S = { st: [], caf: false, cafH: 0, fast: false, sadaqa: false, qBefore: 0, qAfter: 0, qiyam: '', sujood: 0, dua: 0 }

function advice(s: S): string {
  if (s.st.includes('أنا متوتر') || s.caf) return 'ابدأ ببطء: «سبحان الله» أو «لا حول ولا قوة إلا بالله» بنَفَس هادئ، فالتوتر أو المنبهات يؤخران الوصول إلى Alpha.'
  if (s.st.includes('أحتاج إلى التركيز')) return 'جرّب «لا إله إلا الله» بإيقاع منتظم لتثبيت التركيز.'
  if (s.st.includes('أحتاج إلى السكينة') || s.st.includes('أنا متعب')) return 'جرّب «حسبنا الله ونعم الوكيل» أو «سبحان الله وبحمده»، واستمر دون تغيير الإيقاع.'
  if (s.qAfter > 0 || s.qiyam === 'سأقوم الليل') return 'حافظ على هدوء الإيقاع الآن، ثم اختم بقراءة القرآن أو القيام كما نويت.'
  return 'ابدأ بما يناسبك واستمر على إيقاع ثابت، فالثبات أهم من السرعة.'
}

export default function Survey() {
  const [s, setS] = useState<S>(() => ({ ...D, ...load('survey', D) }))
  const set = (p: Partial<S>) => setS((o) => { const n = { ...o, ...p }; save('survey', n); return n })
  const inp = 'rounded-lg border hairline bg-transparent px-3 py-2 text-sm text-[--ink] outline-none w-20'
  const chip = (on: boolean) => `rounded-full border px-3 py-1 text-xs ${on ? 'border-[#d4b67e]/70 text-[#fce1b6]' : 'hairline text-[--ink-dim]'}`
  const row = 'flex items-center justify-between gap-3 text-sm text-[--ink-dim]'
  const yn = (v: boolean, f: (b: boolean) => void) => <button onClick={() => f(!v)} className={chip(v)}>{v ? 'نعم' : 'لا'}</button>

  return (
    <section className="py-8">
      <details className="rounded-xl border hairline p-5">
        <summary className="font-display cursor-pointer text-xl text-[#d4b67e]">الاستبيان الموسع (اختياري)</summary>
        <div className="mt-4 flex flex-col gap-4">
          <div className="flex flex-wrap gap-2">{STATES.map((x) => <button key={x} onClick={() => set({ st: s.st.includes(x) ? s.st.filter((y) => y !== x) : [...s.st, x] })} className={chip(s.st.includes(x))}>{x}</button>)}</div>
          <div className={row}><span>تناولت كافيين اليوم؟</span>{yn(s.caf, (b) => set({ caf: b }))}</div>
          {s.caf && <div className={row}><span>منذ كم ساعة؟</span><input type="number" min={0} value={s.cafH} onChange={(e) => set({ cafH: Math.max(0, +e.target.value || 0) })} className={inp} /></div>}
          <div className={row}><span>هل أنت صائم اليوم؟</span>{yn(s.fast, (b) => set({ fast: b }))}</div>
          <div className={row}><span>هل تصدقت اليوم؟</span>{yn(s.sadaqa, (b) => set({ sadaqa: b }))}</div>
          <div className={row}><span>قراءة القرآن قبل الذكر (دقيقة)</span><input type="number" min={0} value={s.qBefore} onChange={(e) => set({ qBefore: Math.max(0, +e.target.value || 0) })} className={inp} /></div>
          <div className={row}><span>قراءة القرآن بعد الذكر (دقيقة)</span><input type="number" min={0} value={s.qAfter} onChange={(e) => set({ qAfter: Math.max(0, +e.target.value || 0) })} className={inp} /></div>
          <div className="flex flex-wrap gap-2">{QIYAM.map((x) => <button key={x} onClick={() => set({ qiyam: s.qiyam === x ? '' : x })} className={chip(s.qiyam === x)}>{x}</button>)}</div>
          <div className={row}><span>مدة السجود الطويل (دقيقة)</span><input type="number" min={0} value={s.sujood} onChange={(e) => set({ sujood: Math.max(0, +e.target.value || 0) })} className={inp} /></div>
          <div className={row}><span>مدة الدعاء في السجود (دقيقة)</span><input type="number" min={0} value={s.dua} onChange={(e) => set({ dua: Math.max(0, +e.target.value || 0) })} className={inp} /></div>
          <p className="rounded-lg bg-[#d4b67e]/5 p-3 text-sm leading-relaxed text-[#fce1b6]">{advice(s)}</p>
          <p className="text-xs text-[--ink-faint]">هذه الخيارات لتسجيل عواملك الشخصية وتوجيه التوصية فقط، وليست قياسًا ولا نصيحة طبية. البيانات تبقى على جهازك.</p>
        </div>
      </details>
    </section>
  )
}
