import { useEffect, useState } from 'react'
import { load, save } from '@/lib/store'

type Aff = { id: number; t: string; on: boolean }
const DEF: Aff[] = [
  { id: 1, t: 'أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ', on: true },
  { id: 2, t: 'سكينة تنزل على قلبي مع كل ذكر', on: true },
]

export default function Affirm() {
  const [list, setList] = useState<Aff[]>(() => load('affs', DEF))
  const [secs, setSecs] = useState<number>(() => load('affSecs', 8))
  const [auto, setAuto] = useState<boolean>(() => load('affAuto', true))
  const [rand, setRand] = useState<boolean>(() => load('affRand', false))
  const [idx, setIdx] = useState(0)
  const [open, setOpen] = useState(false)
  const [txt, setTxt] = useState('')
  const on = list.filter((a) => a.on)
  const cur = on.length ? on[idx % on.length] : null

  useEffect(() => {
    if (!auto || on.length < 2) return
    const iv = window.setInterval(() => setIdx((i) => (rand ? Math.floor(Math.random() * on.length) : i + 1)), secs * 1000)
    return () => window.clearInterval(iv)
  }, [auto, rand, secs, on.length])

  const upd = (l: Aff[]) => { setList(l); save('affs', l) }
  const inp = 'rounded-lg border hairline bg-transparent px-3 py-2 text-sm text-[--ink] outline-none'

  return (
    <div className="flex flex-col gap-3 pt-5">
      <div className="flex items-center justify-between gap-3">
        <p className="font-display flex-1 text-center text-lg leading-relaxed text-[#fce1b6]">{cur ? cur.t : '—'}</p>
        <button onClick={() => setOpen(!open)} className="text-xs text-[--ink-faint]" aria-label="إدارة التوكيدات">✎</button>
      </div>
      {open && (
        <div className="flex flex-col gap-2 rounded-xl border hairline p-4">
          {list.map((a) => (
            <div key={a.id} className="flex items-center gap-2 text-sm text-[--ink-dim]">
              <input type="checkbox" checked={a.on} onChange={() => upd(list.map((x) => (x.id === a.id ? { ...x, on: !x.on } : x)))} />
              <input value={a.t} onChange={(e) => upd(list.map((x) => (x.id === a.id ? { ...x, t: e.target.value } : x)))} className={inp + ' flex-1'} />
              <button onClick={() => upd(list.filter((x) => x.id !== a.id))} className="text-[--ink-faint]">✕</button>
            </div>
          ))}
          <div className="flex gap-2">
            <input value={txt} onChange={(e) => setTxt(e.target.value)} placeholder="عبارة جديدة" className={inp + ' flex-1'} />
            <button onClick={() => { if (txt.trim()) { upd([...list, { id: Date.now(), t: txt.trim(), on: true }]); setTxt('') } }} className="rounded-lg border border-[#d4b67e]/60 px-4 text-sm text-[#fce1b6]">إضافة</button>
          </div>
          <div className="flex flex-wrap items-center gap-3 text-xs text-[--ink-dim]">
            <label className="flex items-center gap-1"><input type="checkbox" checked={auto} onChange={() => { setAuto(!auto); save('affAuto', !auto) }} />تغيير تلقائي</label>
            <label className="flex items-center gap-1"><input type="checkbox" checked={rand} onChange={() => { setRand(!rand); save('affRand', !rand) }} />عشوائي</label>
            <label className="flex items-center gap-1">كل<input type="number" min={3} value={secs} onChange={(e) => { const v = Math.max(3, +e.target.value || 3); setSecs(v); save('affSecs', v) }} className={inp + ' w-16 py-1'} />ثانية</label>
          </div>
        </div>
      )}
    </div>
  )
}
