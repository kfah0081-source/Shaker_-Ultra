import AmbientWave from '@/sections/AmbientWave'
import DhikrCounter from '@/sections/DhikrCounter'
import JourneyChart from '@/sections/JourneyChart'
import Extras from '@/sections/Extras'
import Affirm from '@/sections/Affirm'
import Survey from '@/sections/Survey'
import Insights from '@/sections/Insights'
import StatePanel from '@/sections/StatePanel'
import { useEffect, useState } from 'react'
import { Activity, TrendingUp, ClipboardList, Hand, Info, Settings } from 'lucide-react'
import { load } from '@/lib/store'
import { useDhikrSession } from '@/hooks/useDhikrSession'

function Seal() {
  return (
    <svg width="52" height="52" viewBox="0 0 100 100" className="shrink-0">
      <defs>
        <path id="sealCircle" d="M50,50 m-38,0 a38,38 0 1,1 76,0 a38,38 0 1,1 -76,0" />
      </defs>
      <g className="seal-rotate">
        <text fontSize="10.5" fill="#af915f" style={{ fontFamily: 'Amiri, serif' }}>
          <textPath href="#sealCircle">
            سُبْحَانَ اللهِ وَبِحَمْدِهِ ۞ سُبْحَانَ اللهِ الْعَظِيمِ ۞
          </textPath>
        </text>
      </g>
      <circle cx="50" cy="50" r="3" fill="#d4b67e" />
      <circle cx="50" cy="50" r="27" fill="none" stroke="rgba(175,145,95,0.35)" strokeWidth="0.8" />
    </svg>
  )
}

export default function Home() {
  const s = useDhikrSession()
  const [, force] = useState(0)
  const [tab, setTab] = useState<string>('home')
  useEffect(() => { document.documentElement.dataset.theme = load('theme', '') }, [])
  const TABS = [
    { id: 'home', label: 'التسبيح', Icon: Hand },
    { id: 'analysis', label: 'التحليل', Icon: Activity },
    { id: 'stats', label: 'الإحصاء', Icon: TrendingUp },
    { id: 'survey', label: 'الاستبيان', Icon: ClipboardList },
    { id: 'settings', label: 'الإعدادات', Icon: Settings },
    { id: 'about', label: 'النموذج', Icon: Info },
  ]

  return (
    <div className="relative min-h-[100dvh]">
      <AmbientWave getElapsed={s.getElapsed} pulse={s.pulse} />
      <div className="dot-grid pointer-events-none fixed inset-0" aria-hidden />

      <div className="safe-b relative mx-auto w-full max-w-6xl px-4 pb-16 sm:px-8">
        {/* الترويسة */}
        <header className="safe-t flex items-center justify-between gap-4 py-5 sm:py-8">
          <div className="flex items-center gap-3 sm:gap-5">
            <Seal />
            <div>
              <h1 className="font-display text-3xl text-[#fce1b6] sm:text-4xl">Shaker OS</h1>
              <p className="mt-1 text-sm text-[--ink-dim]">
                رحلة التسبيح عبر أمواج الدماغ — من بيتا إلى ألفا إلى ثيتا
              </p>
            </div>
          </div>
          <div className="hidden text-left text-[11px] leading-relaxed text-[--ink-faint] md:block">
            نموذج استرشادي تفاعلي
            <br />
            يرسم توقعاً لا قياساً
          </div>
        </header>

        <div className="hairline-b" />

        {tab === 'home' && (
          <>
        <Affirm />

        {/* المقطع الرئيسي */}
        <main className="grid grid-cols-1 gap-8 py-8 sm:py-12 lg:grid-cols-2 lg:gap-10">
          <div className="fade-up">
            <DhikrCounter
              dhikr={s.dhikr}
              count={s.count}
              rounds={s.rounds}
              onTap={s.tap}
              onSelect={s.selectDhikr}
              adhkar={s.adhkar}
              onTarget={(n) => s.setTarget(s.dhikr.id, n)}
            />
          </div>
          <div className="fade-up" style={{ animationDelay: '0.15s' }}>
            <StatePanel
              elapsedSec={s.elapsedSec}
              running={s.running}
              total={s.total}
              onStart={s.start}
              onPause={s.pause}
              onReset={s.reset}
            />
          </div>
        </main>

        <div className="hairline-b" />

        {/* الرسم البياني */}
        <section className="fade-up py-12" style={{ animationDelay: '0.25s' }}>
          <h2 className="font-display mb-2 text-3xl text-[#fce1b6]">خريطة الرحلة والأثر</h2>
          <p className="mb-8 max-w-2xl text-sm leading-relaxed text-[--ink-dim]">
            مع كل دقيقة تسبيح متواصل يهدأ إيقاع الدماغ المتوقع. المسار الذهبي هو جلستك أنت الآن،
            والخط المتقطع يجيب عن سؤال: «لو توقفت في هذه اللحظة، كم يمتد أثر الهدوء بعدي؟»
          </p>
          <JourneyChart elapsedSec={s.elapsedSec} trace={s.trace} />
        </section>
          </>
        )}

        {tab === 'analysis' && <Insights trace={s.trace} elapsedSec={s.elapsedSec} rhythm={s.rhythm} total={s.total} goal={s.goal} sessions={s.sessions} adhkar={s.adhkar} onUndo={s.undo} onManual={s.addManual} />}

        {tab === 'stats' && <Extras view="stats" onCap={() => force((n) => n + 1)} adhkar={s.adhkar} sessions={s.sessions} goal={s.goal} onGoal={s.setGoal} onAdd={s.addCustom} onResetAll={s.resetAll} noticeOn={s.noticeOn} onNotice={s.setNotice} />}

        {tab === 'survey' && <Survey />}

        {tab === 'settings' && <Extras view="settings" onCap={() => force((n) => n + 1)} adhkar={s.adhkar} sessions={s.sessions} goal={s.goal} onGoal={s.setGoal} onAdd={s.addCustom} onResetAll={s.resetAll} noticeOn={s.noticeOn} onNotice={s.setNotice} />}

        {tab === 'about' && (
          <>
        {/* منهجية النموذج */}
        <section className="grid grid-cols-1 gap-10 py-12 md:grid-cols-3">
          {[
            {
              title: 'كيف يُحسب التردد؟',
              body: 'منحنى لوجستي يبدأ من يقظة بيتا (~19 هرتز) وينحدر تدريجياً مع استمرار التسبيح نحو ألفا (~10 هرتز) حول الدقيقة السادسة، ثم يستقر في ثيتا (~5.5 هرتز) بعد نحو اثنتي عشرة دقيقة من المكوث المتواصل.',
            },
            {
              title: 'كيف يُحسب طول الأثر؟',
              body: 'الأثر بعد التوقف يتناسب مع عمق الحالة التي بلغتها ومدة المكوث فيها، ويتشبع عند نحو 45 دقيقة. لذلك ترى المنحنى ينمو ببطء في البداية ثم يتسارع كلما اقتربت من ثيتا وطالت إقامتك فيها.',
            },
            {
              title: 'حدود هذا النموذج',
              body: 'هذا تصوّر تعليمي مستوحى من أدبيات التأمل والذكر، وليس قراءة EEG حقيقية ولا نصيحة طبية. الأجساد تختلف، والخشوع لا يُقاس بالهرتز — الغرض أن ترى لثباتك أثراً يتراكم.',
            },
          ].map((c) => (
            <div key={c.title} className="flex flex-col gap-3">
              <h3 className="font-display text-xl text-[#d4b67e]">{c.title}</h3>
              <p className="text-sm leading-loose text-[--ink-dim]">{c.body}</p>
            </div>
          ))}
        </section>


        <footer className="hairline flex items-center justify-between border-t pt-6 text-[11px] text-[--ink-faint]">
          <span>«أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ»</span>
          <span>مِسبحة — صُنعت للسكينة</span>
        </footer>
          </>
        )}
      </div>
      <nav className="fixed inset-x-0 bottom-0 z-40 flex border-t hairline bg-[#08121c]/95 backdrop-blur" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
        {TABS.map(({ id, label, Icon }) => (
          <button key={id} onClick={() => { setTab(id); window.scrollTo(0, 0) }} className={`flex min-w-0 flex-1 flex-col items-center gap-1 py-2 text-[10px] ${tab === id ? 'text-[#fce1b6]' : 'text-[--ink-faint]'}`}>
            <Icon size={20} strokeWidth={tab === id ? 2.2 : 1.6} />
            <span className="truncate">{label}</span>
          </button>
        ))}
      </nav>
    </div>
  )
}
